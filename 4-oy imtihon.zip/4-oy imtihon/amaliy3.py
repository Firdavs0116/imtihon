son = int(input("Son kiriting: "))

kun = son // 86400

soat = son % 86400 // 3600

daqiqa = son % 86400 % 3600 // 60

soniya = son % 86400 % 3600 % 60
daqiqa = soat 
with open("Imtihon.txt", "w+") as fayl:
    fayl.write(f"Kiritilgan soniyalar: {son}\nKun: {kun}, soat: {soat}, daqiqa: {daqiqa}, soniya: {soniya}")
    
    
with open("Imtihon.txt", "r+") as fayl:
    fayl.read()
    print(f"Kiritilgan soniyalar: {son}\nKun: {kun}, soat: {soat}, daqiqa: {daqiqa}, soniya: {soniya}")