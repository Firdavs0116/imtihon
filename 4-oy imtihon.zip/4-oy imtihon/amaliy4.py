class Book:
    def __init__(self, name, page, price) -> None:
        self.name = name
        self.page = page
        self.price = price
        
    def add_page(self):
        self.page += 10
    
    def on_sail(self):
        if self.page >= 100:
            self.price /= 2
            
    def print_all(self):
        print(f"Kitob nomi - {self.name}")
        print(f"Kitob varaqlari - {self.page}")
        print(f"Kitobning narxi - {self.price}")
        
kitob1 = Book("book1", 40, 10)
kitob2 = Book("book2", 100, 20)
kitob3 = Book("book3", 90, 30)
kitob4 = Book("book4", 80, 40)
kitob5 = Book("book5", 50, 50)

ls = [kitob1,kitob2,kitob3,kitob4,kitob5]
for i in ls:
    i.add_page()
for i in ls:
    i.on_sail()
for i in ls:
    i.print_all()