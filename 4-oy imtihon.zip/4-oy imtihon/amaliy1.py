Product = ['Olma', 'Anor', 'Kartoshka', 'Kadi', 'Xurmo', 'Sabzi', 'Rediska', "Ko'kat"]
K_harf = []
A_harf = []

for i in Product:
    for l in i:
        if l == 'K' or l == 'k':
            K_harf.append(i)
            
        elif l == 'A' or l == 'a':
            A_harf.append(i)
        
h_k = set(K_harf)
h_a = set(A_harf)
print(f"Ichida A harfi bor productlar: {h_a}")
print(f"Ichida K harfi bor productlar: {h_k}")