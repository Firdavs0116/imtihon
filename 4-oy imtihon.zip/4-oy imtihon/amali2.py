dc = {}
for i in range(1):
    ism = input("ism kiriting - ")
    familiya = input("Familiya kiriting - ")
    dc[ism] = familiya

with open("Amaliy2.json", "a") as fl:
    fl.write(f"{dc}") 
    
    
# Json file ga Dumps orqali yozib load orqali o'qir edik lekn qo'llay olmay qoldim