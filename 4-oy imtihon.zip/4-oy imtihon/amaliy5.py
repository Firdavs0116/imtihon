class Employee:
    def __init__(self, surname, position, salary) -> None:
        self.surname = surname
        self.position = position
        self.salary = salary
        
class Enterprise_employee(Employee):
    
    def __init__(self,rating) -> None:
        self.rating = rating
        
    def increase_salary(self):
        
        if self.rating > 0 and self.rating < 75:
            self.salary *= 1.2
            
        elif self.rating < 90 and self.rating > 74:
            self.salary *= 1.4
            
        elif self.rating > 89 and self.rating < 100:
            self.salary *= 1.6
        
        else:
            print("Error!!!")
        
    def print_all(self):
        print(f"Worker surname is {self.surname}, \nposition is {self.position}, \nsalary is {self.salary}")
        
worker1 = Employee(input("Enter surname: "), input("Enter your position: "), input("Enter your salary"))
worker2 = Employee(input("Enter surname: "), input("Enter your position: "), input("Enter your salary"))
worker3 = Employee(input("Enter surname: "), input("Enter your position: "), input("Enter your salary"))
worker4 = Employee(input("Enter surname: "), input("Enter your position: "), input("Enter your salary"))
worker5 = Employee(input("Enter surname: "), input("Enter your position: "), input("Enter your salary"))
# worker1 = Employee("sam", "a", 1) 
# worker2 = Employee("sam2", "a", 1) 
# worker3 = Employee("sam3", "a", 1) 
# worker4 = Employee("sam4", "a", 1) 
# worker5 = Employee("sam5", "a", 1) 
ls = [worker1, worker2, worker3, worker4, worker5]

for i in ls:
    i = Enterprise_employee(input("Enter your rating: "))

for i in ls:
    